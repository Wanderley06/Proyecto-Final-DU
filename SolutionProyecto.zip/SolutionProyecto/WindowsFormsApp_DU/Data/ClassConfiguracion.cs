﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp_DU.Data
{
    internal class ClassConfiguracion
    {
        public static SqlConnection Conectar()
        {
            SqlConnection cn= new SqlConnection("Server=.;DATABASE=dbPrueba;integrated security=true;");
            cn.Open(); 
            return cn;


            
        }
    }
}
