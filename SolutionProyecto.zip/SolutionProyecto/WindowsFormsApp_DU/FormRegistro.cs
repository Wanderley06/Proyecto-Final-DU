﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp_DU.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp_DU
{
    public partial class FormRegistro : Form
    {
        public FormRegistro()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormRegistro_Load(object sender, EventArgs e)
        {
            ClassConfiguracion.Conectar();
            

            dataGridView1.DataSource= llenar_grid();
            
        }

        public DataTable llenar_grid() 
        {
            ClassConfiguracion.Conectar();
            DataTable dt = new DataTable();
            string consulta = "SELECT * FROM dbPrueba";
            SqlCommand cmd = new SqlCommand(consulta,ClassConfiguracion.Conectar());

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            return dt;
        }
    }
}
